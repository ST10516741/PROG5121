package com.mycompany.quickchatapp;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * @author naledi
 */
public class QuickChatAppTest {

   
    private String generateHash(String id, int num, String msg) {
        String[] words = msg.trim().split(" ");
        String first = words[0];
        String last = words[words.length - 1].replaceAll("[^a-zA-Z0-9]", "");
        return (id.substring(0, 2) + ":" + num + ":" + first + last).toUpperCase();
    }

   
    @Test
    public void testMessageReadyToSend() {
        // Message 1: "Hi Mike, can you join us for dinner tonight?" — under 250 chars
        String message = "Hi Mike, can you join us for dinner tonight?";
        String result = message.length() <= 250 ? "Message ready to send."
                : "Message exceeds 250 characters by " + (message.length() - 250) + "; please reduce the size.";
        assertEquals("Message ready to send.", result);
    }

    @Test
    public void testMessageExceeds250Characters() {
        // Message that is over 250 characters
        String message = "a".repeat(260);
        int excess = message.length() - 250;
        String result = message.length() <= 250 ? "Message ready to send."
                : "Message exceeds 250 characters by " + excess + "; please reduce the size.";
        assertEquals("Message exceeds 250 characters by 10; please reduce the size.", result);
    }

    
    @Test
    public void testRecipientCellCorrectlyFormatted() {
        String cell = "+27718693002";
        String result = (cell.matches("^\\+\\d{1,3}\\d{1,10}$") && cell.length() <= 13)
                ? "Cell phone number successfully captured."
                : "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        assertEquals("Cell phone number successfully captured.", result);
    }

    @Test
    public void testRecipientCellIncorrectlyFormatted() {
        String cell = "08575975889"; // no international code
        String result = (cell.matches("^\\+\\d{1,3}\\d{1,10}$") && cell.length() <= 13)
                ? "Cell phone number successfully captured."
                : "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.", result);
    }

   
    @Test
    public void testMessageHashCorrect() {
        // Test Case 1: ID starts with "00", message 0, "Hi Mike, can you join us for dinner tonight?"
        // Expected hash: 00:0:HITONIGHT
        String messageID = "0034567890";
        int messageNum = 0;
        String message = "Hi Mike, can you join us for dinner tonight?";
        String hash = generateHash(messageID, messageNum, message);
        assertEquals("00:0:HITONIGHT", hash);
    }

    
    @Test
    public void testSendMessageReturnsCorrectMessage() {
        // User selected Send Message (case 0)
        String result = "Message successfully sent.";
        assertEquals("Message successfully sent.", result);
    }

    @Test
    public void testDisregardMessageReturnsCorrectMessage() {
        // User selected Disregard Message (case 1)
        String result = "Press 0 to delete the message.";
        assertEquals("Press 0 to delete the message.", result);
    }

    @Test
    public void testStoreMessageReturnsCorrectMessage() {
        // User selected Store Message (case 2)
        String result = "Message successfully stored.";
        assertEquals("Message successfully stored.", result);
    }

    
    @Test
    public void testMessageIDIsCorrectLength() {
        String messageID = QuickChatApp.generateMessageID();
        assertTrue(messageID.length() <= 10);
    }

    @Test
    public void testMessageIDGeneratedNotNull() {
        String messageID = QuickChatApp.generateMessageID();
        assertNotNull(messageID);
    }

    @Test
    public void testTotalMessagesSentStartsAtZero() {
        QuickChatApp.totalMessagesSent = 0;
        assertEquals(0, QuickChatApp.totalMessagesSent);
    }

    @Test
    public void testTotalMessagesSentIncrementsCorrectly() {
        QuickChatApp.totalMessagesSent = 0;
        QuickChatApp.totalMessagesSent++;
        QuickChatApp.totalMessagesSent++;
        assertEquals(2, QuickChatApp.totalMessagesSent);
    }

} // closes class QuickChatAppTest

