
package poepart1;
import java.util.Scanner;

public class POEpart1 { //opens class

  
    public static void main(String[] args) {  // opens main
       
        Scanner scanner = new Scanner(System.in);
        Login login = new Login();
        
        // To track if the user has already registered
        boolean isRegistered = false;
        
        System.out.println("WELCOME TO THE CHAT APP!, Please choose an option.");
        
       // Main menu loops until users chooses Exit
       while (true) {
       System.out.println("\nMain Menu:");
       System.out.println("1. Register");
       System.out.println("2. Login");
       System.out.println("3. Exit");
       System.out.println("Please choose Option");
       
       int choice = scanner.nextInt();
       scanner.nextLine();
       
       switch (choice) {
           case 1: //Registration
        System.out.println("REGISTRATION");
      // This is where user enters full name
        
        System.out.println("Please Enter your first name");
        login.firstName = scanner.nextLine();
        
      // This is where user enters last name
        System.out.println ("Please Enter your last name");
        login.lastName = scanner.nextLine(); //consume newline
        
      /**
       * This is where we introduce our while loop for,username,password,
       * We assume that the condition is true until said otherwise
       */
      while (true) {
          System.out.println("Please Enter Username (must contain '_' and must be max 5 characters)");
          login.username = scanner.nextLine();
          if (login.checkUserName()) {
              System.out.println("Username successfully captured.");
              break;
          } else {
              System.out.println("Username is not correctly formatted; please ensure that username "
              + "contains underscore and is not more than five characters.");
          }
       }
      
      // Loop for password
      while (true) {
          System.out.println("Please enter your password(min 8 chars, 1 capital, 1 number, 1 special char):");
          login.password = scanner.nextLine();
          if (login.checkPasswordComplexity()) {
              System.out.println("Password successfully captured.");
              break;
          } else {
              System.out.println("Password is not correctly formatted; please ensure that password"
              + "contains at least eight characters, a capital letter, a number and a special character. ");    
      }
    }      
      // Loop for cellphone number using rejex
       while (true) {
           System.out.println("Please enter cell phone number (e.g +27738849468)");
           login.cellPhoneNumber = scanner.nextLine();
           if (login.checkCellPhoneNumber()) {
               System.out.println("Cell phone number successfully added.");
               break;
            } else {
               System.out.println("Cell phone number incorrectly formatted or does not contain international code"
               + "please ensure that number starts with +27."); 
           }
       }
       
       isRegistered = true; 
       System.out.println("Registration successful! Welcome, "
       + login.firstName + " " + login.lastName + "  You can now log in.");
       
        System.out.println("Redirecting you to login page.........\n");
        
        //immediately prompts user to log in
           case 2: // Login
             if (!isRegistered) {
                 System.out.println("\nPlease register before logging in.");
                 break;
             }
             
       System.out.println("LOGIN INTO YOUR ACCOUNT");
       System.out.println("Please login in with your registered credentials.");
       System.out.println("Please enter your username");
       String enteredUsername = scanner.nextLine();
       
       System.out.println("Please Enter password");
       String enteredPassword = scanner.nextLine();
       
       System.out.println(login.returnLoginStatus(enteredUsername, enteredPassword));
       break;
        
           case 3: //Exit with goodbye message
       System.out.println("Thank you for using the Chat App. Goodbye, "
       + login.firstName + "!");
       scanner.close(); 
       return; // Exit main and the program ends
       
           default:
               System.out.println("\nInvalid option. Please choose 1, 2 or 3.");
       }        
    }   
  } // closes main
}  //closes class