package poepart1;


public class Login {
    String firstName;
    String lastName;
    String username;
    String password;
    String cellPhoneNumber;
  
    // Theres a reason for the opening of public login but i forgot
    public Login() {
    }
    public Login(String firstName, String lastName, String username, String password, String cellPhoneNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.password = password;
        this.cellPhoneNumber = cellPhoneNumber;
    }
    // Validation methods
    
    /**
     *  To check that the username contains underscore and is max 5 characters,
     *  We are going to introduce Boolean statements
     * @return 
     */
    public boolean checkUserName() {
        return username.contains("_") && username.length() <=5;
    }
    /**
     * TO check the password complexity,we must ensure that it contains:
     * a. at least 8 characters
     * b. a capital letter
     * c. a number
     * d. a special character
     * @return 
     */
    public boolean checkPasswordComplexity() {
        if (password.length() <8)return false;
        
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;
        
        for (char c : password.toCharArray()) {
             if (Character.isUpperCase(c))            hasCapital = true;
            else if (Character.isDigit(c))            hasNumber = true;
            else if (!Character.isLetterOrDigit(c))   hasSpecial = true;
        }
         return hasCapital && hasNumber && hasSpecial;   
    } 
    /**
     * To check cell phone number, we must ensure that it meets the following requirements:
     * a. it must follow the standard rejex system
     * b. must contain international country code +27
     * c. number must not be more than 10 characters long
     * @return 
     */
    public boolean checkCellPhoneNumber() {
        return cellPhoneNumber.matches("^\\+\\d{1,3}\\d{1,10}$")
                && cellPhoneNumber.length() <= 13;
    }
    /**
     * Here we are making sure that when the user registers
     * a. it returns appropriate messages
     * @return 
     */
    public String registerUser() {
        if (!checkUserName()) {
          return "Username is not correctly formatted; please ensure that your username "
                  + "contains underscore and is no more than five characters.";
        }
        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; ensure that your password "
                    + "contains at least eight characters, a capital letter, a number and a special character.";
        }
        if (!checkCellPhoneNumber()) {
            return "Cell phone number incorrectly formatted or does not contain international code "
                    + "please ensure that number starts with +27.";
        }
        return "Username successfully captured."
                + "Password successfuly captured."
                + "Cell phone number successfully added.";
    } //close public string
    /**
     * Now we use this feature to verify the users login credentials, and if wrong it asks for the correct ones until valid
     * @param enteredUsername
     * @param enteredPassword
     * @return 
     */
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        return this.username.equals(enteredUsername) && this.password.equals(enteredPassword);
    }
    /**
     * Now when valid,it then returns login status message or failed login.
     * @param enteredUsername
     * @param enteredPassword
     * @return 
     */
    public String returnLoginStatus(String enteredUsername, String enteredPassword) {
        if (loginUser(enteredUsername, enteredPassword)) {
            return "Welcome " + firstName + " " + lastName + ", it is great to see you again." ;   
        } else { 
           return "User not founds, please try again.";
        }
    }
    } //close public class

   
