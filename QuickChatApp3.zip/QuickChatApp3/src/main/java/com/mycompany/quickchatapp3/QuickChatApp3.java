/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quickchatapp3;
import javax.swing.JOptionPane;
import java.util.*;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
/**
 *
 * @author naledi
 */
public class QuickChatApp3 {
    static String registeredUsername;
    static String registeredPassword;
    static String registeredPhone;

    static int totalMessagesSent = 0;
    static int messageNumber = 0;
    
    // PART 3 ARRAYS — populated as messages are sent
    static ArrayList<String> sentMessagesArray = new ArrayList<>();
    static ArrayList<String> sentRecipientsArray = new ArrayList<>();
    static ArrayList<String> disregardedMessages = new ArrayList<>();
    static ArrayList<String> storedMessages = new ArrayList<>();
    static ArrayList<String> storedRecipients = new ArrayList<>();
    static ArrayList<String> messageHashesArray = new ArrayList<>();
    static ArrayList<String> messageIDsArray = new ArrayList<>();
 
    
    // MAIN
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat.");
        registerUser();

        if (loginUser()) {
            JOptionPane.showMessageDialog(null, "Login successful. Redirecting to QuickChat...");
            runMessageSystem();
        } else {
            JOptionPane.showMessageDialog(null, "Login failed. Exiting app.");
        }
    }

    // REGISTRATION
    public static void registerUser() {
        boolean valid = false;
        while (!valid) {
            registeredUsername = JOptionPane.showInputDialog("Create a username (must contain _ and max 5 chars):");
            if (!(registeredUsername.contains("_") && registeredUsername.length() <= 5)) {
                JOptionPane.showMessageDialog(null, "Invalid username.");
                continue;
            }
            registeredPassword = JOptionPane.showInputDialog("Create password (8+ chars, 1 capital, 1 number, 1 special):");
            if (!registeredPassword.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$")) {
                JOptionPane.showMessageDialog(null, "Invalid password.");
                continue;
            }
            registeredPhone = JOptionPane.showInputDialog("Enter phone number (+27xxxxxxxxx):");
            if (!registeredPhone.matches("^\\+27[6-8]\\d{8}$")) {
                JOptionPane.showMessageDialog(null, "Invalid phone number.");
                continue;
            }
            JOptionPane.showMessageDialog(null, "Registration successful!");
            valid = true;
        }
    }

    // LOGIN
    public static boolean loginUser() {
        String user = JOptionPane.showInputDialog("Login - Enter your username: ");
        String pass = JOptionPane.showInputDialog("Enter your password");
        return user.equals(registeredUsername) && pass.equals(registeredPassword);
    }

    // MAIN MENU — 4 options
    public static void runMessageSystem() {
        boolean keepRunning = true;
        while (keepRunning) {
            String[] options = {"Send Messages", "Show Recently Sent", "Stored Messages", "Quit"};
            int choice = JOptionPane.showOptionDialog(null, "Choose an option:", "Main Menu",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

            switch (choice) {
                case 0 -> sendMessages();
                case 1 -> JOptionPane.showMessageDialog(null, "Coming Soon.");
                case 2 -> storedMessagesMenu();
                case 3 -> {
                    keepRunning = false;
                    JOptionPane.showMessageDialog(null, "Goodbye " + registeredUsername + "!");
                }
            }
        }
    }
    
    // SEND MESSAGES
    public static void sendMessages() {
        int count = Integer.parseInt(JOptionPane.showInputDialog("How many messages would you like to send?"));

        for (int i = 0; i < count; i++) {
            messageNumber++;
            String messageID = generateMessageID();

            // Validate recipient
            String recipient;
            while (true) {
                recipient = JOptionPane.showInputDialog("Enter recipient cell number (+27xxxxxxxxx):");
                if (recipient.matches("^\\+\\d{1,3}\\d{1,10}$") && recipient.length() <= 13) {
                    JOptionPane.showMessageDialog(null, "Cell phone number successfully captured.");
                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "Cell phone number is incorrectly formatted or does not contain "
                            + "an international code. Please correct the number and try again.");
                }
            }

            // Validate message length
            String message;
            while (true) {
                message = JOptionPane.showInputDialog("Enter your message (max 250 characters):");
                if (message.length() <= 250) {
                    JOptionPane.showMessageDialog(null, "Message ready to send.");
                    break;
                } else {
                    int excess = message.length() - 250;
                    JOptionPane.showMessageDialog(null, "Message exceeds 250 characters by " + excess
                            + "; please reduce the size.");
                }
            }

            String hash = generateMessageHash(messageID, messageNumber, message);

            // Always store ID and hash
            messageIDsArray.add(messageID);
            messageHashesArray.add(hash);

            // User chooses action
            String[] actions = {"Send", "Disregard", "Store"};
            int action = JOptionPane.showOptionDialog(null, "What do you want to do?", "Message Options",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, actions, actions[0]);

            switch (action) {
                case 0 -> {
                    totalMessagesSent++;
                    sentMessagesArray.add(message);
                    sentRecipientsArray.add(recipient);
                    displayMessageDetails(messageID, hash, recipient, message);
                    JOptionPane.showMessageDialog(null, "Message successfully sent.");
                }
                case 1 -> {
                    disregardedMessages.add(message);
                    JOptionPane.showMessageDialog(null, "Press 0 to delete the message.");
                }
                case 2 -> {
                    storedMessages.add(message);
                    storedRecipients.add(recipient);
                    writeMessageToJSON(messageID, hash, recipient, message);
                    JOptionPane.showMessageDialog(null, "Message successfully stored.");
                }
            }
        }
        JOptionPane.showMessageDialog(null, "Total messages sent: " + totalMessagesSent);
    }

    // STORED MESSAGES MENU
    public static void storedMessagesMenu() {
        loadStoredMessagesFromJSON();

        boolean back = false;
        while (!back) {
            String[] options = {
                "a) Display sender and recipient",
                "b) Display longest message",
                "c) Search by Message ID",
                "d) Search by recipient",
                "e) Delete by message hash",
                "f) Display full report",
                "Back to Main Menu"
            };
            int choice = JOptionPane.showOptionDialog(null, "Stored Messages Menu:", "Stored Messages",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

            switch (choice) {
                case 0 -> displaySenderAndRecipient();
                case 1 -> displayLongestMessage();
                case 2 -> searchByMessageID();
                case 3 -> searchByRecipient();
                case 4 -> deleteByMessageHash();
                case 5 -> displayFullReport();
                case 6 -> back = true;
            }
        }
    }

    // a) Display sender and recipient
    public static void displaySenderAndRecipient() {
        if (storedMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No stored messages.");
            return;
        }
        StringBuilder sb = new StringBuilder("=== Stored Messages — Sender & Recipient ===\n");
        for (int i = 0; i < storedMessages.size(); i++) {
            sb.append("Sender: ").append(registeredUsername)
              .append(" | Recipient: ").append(storedRecipients.size() > i ? storedRecipients.get(i) : "Unknown")
              .append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    // b) Display the longest message
    public static String displayLongestMessage() {
        if (sentMessagesArray.isEmpty() && storedMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages available.");
            return "No messages available.";
        }
        ArrayList<String> allMessages = new ArrayList<>();
        allMessages.addAll(sentMessagesArray);
        allMessages.addAll(storedMessages);

        String longest = allMessages.get(0);
        for (String msg : allMessages) {
            if (msg.length() > longest.length()) {
                longest = msg;
            }
        }
        JOptionPane.showMessageDialog(null, "Longest Message:\n" + longest);
        return longest;
    }

    // c) Search by message ID
    public static String searchByMessageID() {
        String searchID = JOptionPane.showInputDialog("Enter Message ID to search:");
        for (int i = 0; i < messageIDsArray.size(); i++) {
            if (messageIDsArray.get(i).equals(searchID)) {
                if (i < sentMessagesArray.size()) {
                    String result = "Recipient: " + sentRecipientsArray.get(i)
                            + "\nMessage: " + sentMessagesArray.get(i);
                    JOptionPane.showMessageDialog(null, result);
                    return sentMessagesArray.get(i);
                }
                int storedIndex = i - sentMessagesArray.size();
                if (storedIndex < storedMessages.size()) {
                    String result = "Recipient: " + storedRecipients.get(storedIndex)
                            + "\nMessage: " + storedMessages.get(storedIndex);
                    JOptionPane.showMessageDialog(null, result);
                    return storedMessages.get(storedIndex);
                }
            }
        }
        JOptionPane.showMessageDialog(null, "Message ID not found.");
        return "Message ID not found.";
    }

    // d) Search by recipient
    public static String searchByRecipient() {
        String searchRecipient = JOptionPane.showInputDialog("Enter recipient number to search:");
        StringBuilder sb = new StringBuilder("Messages for " + searchRecipient + ":\n");
        boolean found = false;

        for (int i = 0; i < sentRecipientsArray.size(); i++) {
            if (sentRecipientsArray.get(i).equals(searchRecipient)) {
                sb.append(sentMessagesArray.get(i)).append("\n");
                found = true;
            }
        }
        for (int i = 0; i < storedRecipients.size(); i++) {
            if (storedRecipients.get(i).equals(searchRecipient)) {
                sb.append(storedMessages.get(i)).append("\n");
                found = true;
            }
        }
        if (!found) {
            JOptionPane.showMessageDialog(null, "No messages found for this recipient.");
            return "No messages found for this recipient.";
        }
        JOptionPane.showMessageDialog(null, sb.toString());
        return sb.toString();
    }

    // e) Delete by message hash
    public static String deleteByMessageHash() {
        String searchHash = JOptionPane.showInputDialog("Enter message hash to delete:");
        for (int i = 0; i < messageHashesArray.size(); i++) {
            if (messageHashesArray.get(i).equalsIgnoreCase(searchHash)) {
                String deletedMsg = "";
                if (i < sentMessagesArray.size()) {
                    deletedMsg = sentMessagesArray.get(i);
                    sentMessagesArray.remove(i);
                    sentRecipientsArray.remove(i);
                } else {
                    int storedIndex = i - sentMessagesArray.size();
                    if (storedIndex < storedMessages.size()) {
                        deletedMsg = storedMessages.get(storedIndex);
                        storedMessages.remove(storedIndex);
                        storedRecipients.remove(storedIndex);
                    }
                }
                messageHashesArray.remove(i);
                messageIDsArray.remove(i);
                String result = "Message: \"" + deletedMsg + "\" successfully deleted.";
                JOptionPane.showMessageDialog(null, result);
                return result;
            }
        }
        JOptionPane.showMessageDialog(null, "Hash not found.");
        return "Hash not found.";
    }

    // f) Display full report
    public static String displayFullReport() {
        if (sentMessagesArray.isEmpty() && storedMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages to display.");
            return "No messages to display.";
        }
        StringBuilder sb = new StringBuilder("===== FULL MESSAGE REPORT =====\n\n");
        sb.append("--- SENT MESSAGES ---\n");
        for (int i = 0; i < sentMessagesArray.size(); i++) {
            sb.append("Hash: ").append(i < messageHashesArray.size() ? messageHashesArray.get(i) : "N/A").append("\n");
            sb.append("Recipient: ").append(i < sentRecipientsArray.size() ? sentRecipientsArray.get(i) : "N/A").append("\n");
            sb.append("Message: ").append(sentMessagesArray.get(i)).append("\n\n");
        }
        sb.append("--- STORED MESSAGES ---\n");
        for (int i = 0; i < storedMessages.size(); i++) {
            int hashIndex = sentMessagesArray.size() + i;
            sb.append("Hash: ").append(hashIndex < messageHashesArray.size() ? messageHashesArray.get(hashIndex) : "N/A").append("\n");
            sb.append("Recipient: ").append(i < storedRecipients.size() ? storedRecipients.get(i) : "N/A").append("\n");
            sb.append("Message: ").append(storedMessages.get(i)).append("\n\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
        return sb.toString();
    }

    // LOAD STORED MESSAGES FROM JSON
    public static void loadStoredMessagesFromJSON() {
        try {
            if (!Files.exists(Paths.get("Jsonnew.json"))) return;
            String content = new String(Files.readAllBytes(Paths.get("Jsonnew.json")));
            String[] entries = content.split("\\},");
            for (String entry : entries) {
                if (entry.contains("\"Message\"")) {
                    int start = entry.indexOf("\"Message\": \"") + 12;
                    int end = entry.indexOf("\"", start);
                    if (start > 11 && end > start) {
                        String msg = entry.substring(start, end);
                        if (!storedMessages.contains(msg)) {
                            storedMessages.add(msg);
                        }
                    }
                }
                if (entry.contains("\"Recipient\"")) {
                    int start = entry.indexOf("\"Recipient\": \"") + 14;
                    int end = entry.indexOf("\"", start);
                    if (start > 13 && end > start) {
                        String rec = entry.substring(start, end);
                        if (storedRecipients.size() < storedMessages.size()) {
                            storedRecipients.add(rec);
                        }
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading JSON file: " + e.getMessage());
        }
    }

    // HELPER METHODS
    public static String generateMessageID() {
        return String.format("%010d", new Random().nextInt(1_000_000_000));
    }

    public static String generateMessageHash(String id, int num, String msg) {
        String[] words = msg.trim().split(" ");
        String first = words[0];
        String last = words[words.length - 1].replaceAll("[^a-zA-Z0-9]", "");
        return (id.substring(0, 2) + ":" + num + ":" + first + last).toUpperCase();
    }

    public static void displayMessageDetails(String id, String hash, String recipient, String message) {
        JOptionPane.showMessageDialog(null,
                "Message ID: " + id
                + "\nHash: " + hash
                + "\nRecipient: " + recipient
                + "\nMessage: " + message);
    }

    public static void writeMessageToJSON(String messageID, String hash, String recipient, String message) {
        StringBuilder jsonEntry = new StringBuilder();
        jsonEntry.append("{\n");
        jsonEntry.append(" \"MessageID\": \"").append(messageID).append("\",\n");
        jsonEntry.append(" \"MessageHash\":\"").append(hash).append("\",\n");
        jsonEntry.append(" \"Recipient\": \"").append(recipient).append("\",\n");
        jsonEntry.append(" \"Message\": \"").append(message.replace("\"", "\\\"")).append("\"\n");
        jsonEntry.append("},\n");

        try (FileWriter file = new FileWriter("Jsonnew.json", true)) {
            file.write(jsonEntry.toString());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing file: " + e.getMessage());
        }
    }
    
} //closes main class
